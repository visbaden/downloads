#include <openssl/whrlpool.h>

void whirlpool_block(WHIRLPOOL_CTX *,const void *,size_t);
