== Install

npm install
nodejs ./coord.js

== Development

http://www.jslint.com/

== Debugging

sudo npm install -g node-inspector
node-debug coord.js
