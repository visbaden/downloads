
.. _Examples_Matrix:

Examples, Matrix Specification
******************************

.. toctree::
   :maxdepth: 1

   Regression_Matrix
   FactorAnalysis_Matrix
   TimeSeries_Matrix
   MultipleGroups_Matrix
   GeneticEpi_Matrix
   DefinitionMeans_Matrix
   Ordinal_Matrix
   GrowthMixtureModel_Matrix
   Likelihood_Matrix
