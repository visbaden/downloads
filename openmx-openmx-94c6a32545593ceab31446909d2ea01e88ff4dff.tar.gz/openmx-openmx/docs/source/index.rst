Welcome to OpenMx's documentation!
==================================

.. toctree::
   :maxdepth: 3

   Introduction 

   Examples_Path

   Examples_Matrix
  
   ItemFactorAnalysis

   Advanced_Concepts

   changes


Reference
=========

* `OpenMx R documentation <_static/Rdoc/00Index.html>`_

Indices and tables
==================

..
  DO NOT EXECUTE
  these three lines are commented out
  * :ref:`genindex`
  * :ref:`modindex`

* :ref:`search`

