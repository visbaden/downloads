:tocdepth: 2

.. _changes:

Changes in OpenMx
*****************

.. include:: ../../CHANGES