.. _Introduction:

Introduction
************

.. toctree::
   :maxdepth: 1

   NewBeginnersGuide
   AlternativeApproaches
