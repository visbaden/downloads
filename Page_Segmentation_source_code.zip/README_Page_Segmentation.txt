Readme for the page segmentation based on SVM-struct framework.
-----------------------------------------------
Lidong Bing, 11.06.2014

You should put the folder "glpk" containing the ILP solver in the same directory as the executive learning and inference programs.

To run the training procedure, use the command:
svm_pageseg_learn -c 5 -e 0.5 -v 4 test_data/train_d9 test_data/model/d9.model

To run the inference procedure, use the command:
svm_pageseg_classify test_data/train_d9 test_data/model/d9.model test_data/test/out

For more details, get the help information with "svm_pageseg_learn -" and "svm_pageseg_classify -".
